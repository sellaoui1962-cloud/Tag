package com.example.mentionassist

import com.example.mentionassist.core.MentionHistory
import com.example.mentionassist.core.TimerTracker
import com.example.mentionassist.vision.TimerReader
import org.junit.Assert.*
import org.junit.Test

class LogicTest {
    @Test fun repeatedMentionGetsDots() {
        val h = MentionHistory()
        assertEquals("@nadie", h.peekNext("nadie")); h.commit("nadie")
        assertEquals("@nadie .", h.peekNext("nadie")); h.commit("nadie")
        assertEquals("@nadie ..", h.peekNext("nadie")); h.commit("nadie")
        assertEquals("@other", h.peekNext("other")); h.commit("other")
        assertEquals("@nadie", h.peekNext("nadie"))
    }
    @Test fun failedSendDoesNotCommit() {
        val h = MentionHistory(); h.commit("a")
        assertEquals("@a .", h.peekNext("a"))
        assertEquals("@a .", h.peekNext("a")) // لم يُسجَّل شيء
    }
    @Test fun timerParsing() {
        assertEquals(7, TimerReader.parse("00:07")); assertEquals(75, TimerReader.parse(" 01:15 "))
        assertNull(TimerReader.parse("الوقت 00:07")); assertNull(TimerReader.parse("00:77"))
    }
    @Test fun trackerEstimatesEnd() {
        val t = TimerTracker()
        t.onReading(7, 0); t.onReading(6, 1000); t.onReading(5, 2000); t.onReading(4, 3000)
        val rem = t.remainingMs(3000)!!
        assertTrue("rem=$rem", rem in 3000..4000)
        assertTrue(t.isActive(3000)); t.onReading(0, 7000); assertFalse(t.isActive(7000))
        assertFalse(t.isActive(20000))
    }
}
