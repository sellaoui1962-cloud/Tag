package com.example.mentionassist.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.Settings
import com.example.mentionassist.core.TimerTracker
import com.example.mentionassist.overlay.OverlayManager
import com.example.mentionassist.vision.SeatLocator
import com.example.mentionassist.vision.TextDetector
import com.example.mentionassist.vision.TimerReader
import kotlin.coroutines.resume
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.math.max

class AssistService : AccessibilityService() {
    lateinit var settings: Settings
    private lateinit var overlay: OverlayManager
    private lateinit var engine: MentionEngine
    private val tracker = TimerTracker()
    private val detector by lazy { TextDetector() }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: Job? = null
    private var misses = 0
    private val ocrWidth = 720

    override fun onServiceConnected() {
        instance = this
        settings = Settings(this)
        overlay = OverlayManager(this, settings)
        engine = MentionEngine(this, settings, tracker, ChatSender(this, settings))
        AppState.serviceConnected.value = true
        scope.launch { AppState.running.collect { if (it) startLoop() else stopLoop() } }
        scope.launch {   // تحديث حالة اللوحة العائمة
            AppState.pendingConfirm.collect { overlay.setPanelStatus(AppState.status.value, it != null) }
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { killSwitch() }
    override fun onDestroy() {
        instance = null; AppState.serviceConnected.value = false
        scope.coroutineContext[Job]?.cancel(); overlay.removeAll(); detector.close(); super.onDestroy()
    }

    fun killSwitch() { engine.killSwitch(); overlay.removeAll() }
    fun resetHistory() = engine.history.reset()
    fun pickPoint(hint: String, cb: (Int, Int) -> Unit) = overlay.pickPoint(hint, cb)

    private fun startLoop() {
        if (loop?.isActive == true) return
        AppState.status.value = "قيد التشغيل"
        val h = resources.displayMetrics.heightPixels
        overlay.showPanel(h, onStop = { killSwitch() }, onConfirm = { engine.confirmSend() })
        loop = scope.launch { captureLoop() }
    }

    private fun stopLoop() { loop?.cancel(); loop = null; overlay.removeAll(); tracker.reset() }

    private fun keyboardVisible() = windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD }

    private suspend fun captureLoop() {
        val dm = resources.displayMetrics
        while (scope.isActive && AppState.running.value) {
            val loopStart = SystemClock.elapsedRealtime()
            val pkg = rootInActiveWindow?.packageName?.toString().orEmpty()
            if (pkg.isNotEmpty() && !pkg.startsWith("com.example.mentionassist")) AppState.foregroundPkg.value = pkg
            val inGame = pkg.contains(settings.gamePkgContains, ignoreCase = true)
            if (inGame) {
                val shot = captureScreen()
                if (shot != null) {
                    val capAt = SystemClock.elapsedRealtime() - settings.captureDelayMs
                    try { processFrame(shot, capAt, dm.widthPixels, dm.heightPixels) } catch (_: Exception) {}
                    shot.recycle()
                }
            }
            val elapsed = SystemClock.elapsedRealtime() - loopStart
            delay(max(50L, 1000L - elapsed))   // قيد النظام على لقطات الشاشة ≈ لقطة/ثانية
        }
    }

    private suspend fun processFrame(shot: Bitmap, capAt: Long, sw: Int, sh: Int) {
        val (lines, bmp) = withContext(Dispatchers.Default) {
            val scaled = Bitmap.createScaledBitmap(shot, ocrWidth, (ocrWidth * shot.height.toFloat() / shot.width).toInt(), true)
            detector.detect(scaled) to scaled
        }
        // المؤقّت
        val rd = TimerReader.find(lines) { hasHourglass(bmp, it) }
        if (rd != null) tracker.onReading(rd.seconds, capAt)
        val now = SystemClock.elapsedRealtime()
        AppState.timerText.value = tracker.remainingMs(now)?.let { "%.1f ث".format(it / 1000f) } ?: "--"
        AppState.timerConfidence.value = tracker.confidence(now)

        // اللاعبون
        if (keyboardVisible()) { dropSeats(); bmp.recycle(); return }
        val locator = SeatLocator(settings) { cx, cy, r -> hasAvatar(bmp, cx / sw, cy / sh, r / sw) }
        val seats = locator.locate(lines, sw, sh)
        bmp.recycle()
        if (seats.isEmpty()) { if (++misses >= 2) dropSeats() } else { misses = 0; AppState.seats.value = seats }
        if (seats.isNotEmpty()) overlay.renderSeats(seats, AppState.selectedKey.value) { engine.onSeatTapped(it) }
        overlay.setPanelStatus("${AppState.timerText.value}", AppState.pendingConfirm.value != null)
    }

    /**
     * أيقونة الساعة الرملية: ألوان مشبعة (أزرق/ذهبي) في مربع يمين النص، مع خلفية سوداء للكبسولة يسار النص.
     * قياس على لقطة واحدة: المنطقة ≈14% بكسلات مشبعة مقابل ≈0.5% يسار النص، لذا العتبة منخفضة ومُعايَرة تقريبيًا.
     */
    private fun hasHourglass(bmp: Bitmap, ln: com.example.mentionassist.core.OcrLine): Boolean {
        val w = bmp.width; val h = bmp.height
        val th = (ln.h * h).coerceAtLeast(8f)
        val l = (ln.r * w + 0.2f * th).toInt(); val r = (ln.r * w + 3f * th).toInt().coerceAtMost(w - 1)
        val t = (ln.cy * h - 1.3f * th).toInt().coerceAtLeast(0); val b = (ln.cy * h + 1.3f * th).toInt().coerceAtMost(h - 1)
        if (r <= l || b <= t) return false
        var n = 0; var colored = 0
        for (y in t..b step 2) for (x in l..r step 2) {
            val p = bmp.getPixel(x, y)
            val rr = ((p shr 16) and 255) / 255f; val gg = ((p shr 8) and 255) / 255f; val bb = (p and 255) / 255f
            val mx = maxOf(rr, gg, bb); val mn = minOf(rr, gg, bb)
            n++; if (mx > 0.45f && (mx - mn) / (mx + 1e-6f) > 0.5f) colored++
        }
        if (n == 0 || colored.toFloat() / n < 0.07f) return false
        // الكبسولة داكنة يسار النص
        val x0 = (ln.l * w - th).toInt().coerceAtLeast(0); val x1 = (ln.l * w).toInt().coerceAtLeast(x0 + 1).coerceAtMost(w - 1)
        var sum = 0.0; var c = 0
        for (y in t..b step 2) for (x in x0..x1 step 2) {
            val p = bmp.getPixel(x, y)
            sum += 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255); c++
        }
        return c > 0 && sum / c < 60
    }

    private fun dropSeats() { AppState.seats.value = emptyList(); overlay.clearSeats() }

    /** تباين لوني داخل الدائرة: وجود صورة شخصية وليس خلفية فارغة. fx,fy,fr نسب من العرض/الارتفاع/العرض. */
    private fun hasAvatar(bmp: Bitmap, fx: Float, fy: Float, fr: Float): Boolean {
        val cx = (fx * bmp.width).toInt(); val cy = (fy * bmp.height * 1f).toInt()
        val rr = (fr * bmp.width * 0.7f).toInt().coerceAtLeast(4)
        var n = 0; var sum = 0.0; var sum2 = 0.0
        val step = max(1, rr / 6)
        var y = cy - rr
        while (y <= cy + rr) {
            var x = cx - rr
            while (x <= cx + rr) {
                if (x in 0 until bmp.width && y in 0 until bmp.height) {
                    val p = bmp.getPixel(x, y)
                    val l = 0.299 * ((p shr 16) and 255) + 0.587 * ((p shr 8) and 255) + 0.114 * (p and 255)
                    sum += l; sum2 += l * l; n++
                }
                x += step
            }
            y += step
        }
        if (n < 9) return false
        val mean = sum / n
        return Math.sqrt((sum2 / n - mean * mean).coerceAtLeast(0.0)) > 46
    }

    private suspend fun captureScreen(): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hb = r.hardwareBuffer
                val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle(); hb.close()
                if (cont.isActive) cont.resume(soft)
            }
            override fun onFailure(errorCode: Int) { if (cont.isActive) cont.resume(null) }
        })
    }

    companion object { @Volatile var instance: AssistService? = null }
}
