package com.example.mentionassist.vision

import com.example.mentionassist.core.OcrLine
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings
import kotlin.math.abs

/**
 * يحدد مقاعد اللاعبين من أسمائهم المقروءة (OCR). من الصورة المرفقة:
 *  - المقاعد شبكة أعمدة عند x = 0.1/0.3/0.5/0.7/0.9 من العرض.
 *  - مركز الدائرة فوق منتصف الاسم بحوالي 0.125 من العرض، ونصف القطر ≈ 0.07 من العرض.
 *  - شريط الجمهور (دوائر صغيرة بالأعلى) خارج النطاق الرأسي المسموح [yMin, yMax].
 *  - المايكات المقفلة لا اسم لاعب لها، فلا يُرسم عليها شيء.
 * كل هذه النسب قابلة للمعايرة من الإعدادات.
 */
class SeatLocator(private val s: Settings, private val hasAvatar: (cx: Float, cy: Float, r: Float) -> Boolean = { _, _, _ -> true }) {

    fun locate(lines: List<OcrLine>, screenW: Int, screenH: Int): List<Seat> {
        val colX = (0 until s.colCount).map { (s.colStart + it * s.colPitch) / 1000f }
        val seats = ArrayList<Seat>()
        for (ln in lines) {
            val name = cleanName(ln.text) ?: continue
            if (ln.cy < s.yMin / 1000f || ln.cy > s.yMax / 1000f) continue
            val colIdx = colX.indices.minByOrNull { abs(colX[it] - ln.cx) } ?: continue
            if (abs(colX[colIdx] - ln.cx) > s.colPitch / 2000f) continue
            val cxPx = colX[colIdx] * screenW
            val cyPx = ln.cy * screenH - s.circleOffsetY / 1000f * screenW
            val rPx = s.radius / 1000f * screenW * (s.sizePct / 100f)
            if (cyPx / screenH < s.yMin / 1000f - 0.02f) continue
            // تحقق بصري: يوجد صورة (تباين) فعلًا داخل الدائرة وليس خلفية فارغة
            if (!hasAvatar(cxPx, cyPx, rPx)) continue
            val row = ((cyPx / screenW) / 0.25f).toInt()
            seats += Seat(name, cxPx, cyPx, rPx, ln.conf, colIdx, row)
        }
        // إزالة التكرار (نفس الدائرة من سطرين)
        return seats.sortedByDescending { it.conf }
            .distinctBy { it.col to it.row }
            .sortedWith(compareBy({ it.row }, { it.col }))
    }

    companion object {
        /** ينظّف الاسم: يرفض النصوص القصيرة/الرموز فقط/الأوقات. لا يحذف شيئًا من داخل الاسم. */
        fun cleanName(raw: String): String? {
            val t = raw.trim()
            if (t.length < 2) return null
            if (!t.any { it.isLetterOrDigit() }) return null
            if (TimerReader.parse(t) != null) return null
            return t
        }
    }
}
