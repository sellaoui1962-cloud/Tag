package com.example.mentionassist.vision

import com.example.mentionassist.core.OcrLine

/**
 * يبحث عن المؤقّت (صيغة 00:07) في أي مكان بالشاشة. لأن المؤقّت قد يتحرك،
 * لا نعتمد على موضع ثابت: نقبل سطرًا نصه كله mm:ss ونختار الأكبر حجمًا،
 * ونتجاهل السطور الصغيرة داخل منطقة الدردشة (رسالة "بدأ ... الوقت لمدة 00:07").
 */
object TimerReader {
    private val rx = Regex("^\\s*(\\d{1,2})\\s*[:：;]\\s*(\\d{2})\\s*$")

    data class Reading(val seconds: Int, val line: OcrLine)

    fun parse(text: String): Int? {
        val m = rx.matchEntire(text) ?: return null
        val mm = m.groupValues[1].toInt(); val ss = m.groupValues[2].toInt()
        if (ss > 59 || mm > 59) return null
        return mm * 60 + ss
    }

    /** hasHourglass: يتحقق بصريًا من وجود أيقونة الساعة الرملية بجوار النص (أي وقت يُقبل، لا 00:07 فقط). */
    fun find(lines: List<OcrLine>, hasHourglass: (OcrLine) -> Boolean = { true }): Reading? =
        lines.mapNotNull { ln -> parse(ln.text)?.let { Reading(it, ln) } }
            .filter { hasHourglass(it.line) }
            .filter { !(it.line.cx > 0.45f && it.line.cy > 0.50f && it.line.h < 0.016f) }
            .maxByOrNull { it.line.h }
}
