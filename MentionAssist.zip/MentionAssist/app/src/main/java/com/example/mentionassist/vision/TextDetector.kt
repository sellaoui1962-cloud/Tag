package com.example.mentionassist.vision

import android.graphics.Bitmap
import com.example.mentionassist.core.OcrLine
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine

/** OCR لاتيني دون إنترنت. ملاحظة: النموذج لا يقرأ العربية، لذا الأسماء العربية لن تُستخرج. */
class TextDetector {
    private val client = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun detect(bmp: Bitmap): List<OcrLine> = suspendCancellableCoroutine { cont ->
        client.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { text ->
                val w = bmp.width.toFloat(); val h = bmp.height.toFloat()
                val out = text.textBlocks.flatMap { it.lines }.mapNotNull { ln ->
                    val bb = ln.boundingBox ?: return@mapNotNull null
                    OcrLine(ln.text, bb.left / w, bb.top / h, bb.right / w, bb.bottom / h, ln.confidence)
                }
                cont.resume(out)
            }
            .addOnFailureListener { cont.resumeWithException(it) }
    }

    fun close() = client.close()
}
