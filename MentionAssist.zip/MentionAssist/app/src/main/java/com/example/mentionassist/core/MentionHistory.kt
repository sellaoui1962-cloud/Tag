package com.example.mentionassist.core

/**
 * يمنع إرسال النص نفسه مرتين متتاليتين:
 *   @nadie  ->  @nadie .  ->  @nadie ..  ...
 * النقاط تُضاف بعد معرّف اللاعب (بمسافة) ولا تدخل داخل المعرّف نفسه.
 * تتغير الصيغة إلى @اسم عادي فور تغيّر اللاعب المستهدف.
 */
class MentionHistory {
    private var lastKey: String? = null
    private var repeats = 0

    fun peekNext(name: String): String {
        val clean = name.trim()
        return if (normalize(clean) == lastKey) "@$clean ${".".repeat(repeats + 1)}" else "@$clean"
    }

    /** يُستدعى بعد محاولة الإرسال (مؤكدة أو غير مؤكدة) لتفادي تطابق الرسالتين. */
    fun commit(name: String) {
        val k = normalize(name)
        if (k == lastKey) repeats++ else { lastKey = k; repeats = 0 }
    }

    fun reset() { lastKey = null; repeats = 0 }
}
