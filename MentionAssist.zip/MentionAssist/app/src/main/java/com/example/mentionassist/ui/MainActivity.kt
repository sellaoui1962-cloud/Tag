package com.example.mentionassist.ui

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.Settings
import com.example.mentionassist.service.AssistService
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private lateinit var s: Settings
    private lateinit var root: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var timerTv: TextView
    private lateinit var selTv: TextView
    private lateinit var logTv: TextView
    private lateinit var playersBox: LinearLayout
    private lateinit var startBtn: Button
    private var lastPlayers = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun section(t: String) { root.addView(tv(t, 16f, true).apply { setPadding(0, dp(14), 0, dp(4)); setTextColor(Color.parseColor("#1A237E")) }) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

    private fun slider(label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
        val lbl = tv("$label: ${get()}")
        val sb = SeekBar(this).apply {
            this.max = max - min; progress = get() - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { set(p + min); lbl.text = "$label: ${p + min}" }
                override fun onStartTrackingTouch(b: SeekBar?) {}
                override fun onStopTrackingTouch(b: SeekBar?) {}
            })
        }
        root.addView(lbl); root.addView(sb)
    }

    private fun check(label: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        root.addView(CheckBox(this).apply { text = label; isChecked = get(); setOnCheckedChangeListener { _, c -> set(c) } })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        s = Settings(this)
        val sv = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32)); layoutDirection = View.LAYOUT_DIRECTION_RTL }
        sv.addView(root); setContentView(sv)

        root.addView(tv("مساعد المنشنة", 22f, true))
        statusTv = tv("الحالة: متوقف"); timerTv = tv("الوقت المتبقي: -- | ثقة: 0%"); selTv = tv("اللاعب المحدد: —")
        root.addView(statusTv); root.addView(timerTv); root.addView(selTv)

        startBtn = btn("ابدأ المساعدة") { toggle() }
        root.addView(startBtn)
        root.addView(btn("■ إيقاف فوري لكل الأتمتة") { AssistService.instance?.killSwitch() ?: run { AppState.running.value = false } }
            .apply { setBackgroundColor(Color.rgb(200, 30, 30)); setTextColor(Color.WHITE) })
        root.addView(btn("فتح إعدادات الوصول (تفعيل الخدمة)") { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) })

        section("مظهر الدوائر")
        slider("الشفافية (alpha)", 20, 255, { s.alpha }, { s.alpha = it })
        slider("الحجم %", 50, 160, { s.sizePct }, { s.sizePct = it })

        section("المعايرة (إن لم تنطبق الدوائر على المايكات)")
        slider("إزاحة الدائرة فوق الاسم ‰", 60, 200, { s.circleOffsetY }, { s.circleOffsetY = it })
        slider("نصف القطر ‰ من العرض", 40, 110, { s.radius }, { s.radius = it })
        slider("بداية الأعمدة ‰", 50, 200, { s.colStart }, { s.colStart = it })
        slider("المسافة بين الأعمدة ‰", 150, 260, { s.colPitch }, { s.colPitch = it })
        slider("حد المنطقة العلوي ‰ من الارتفاع", 100, 400, { s.yMin }, { s.yMin = it })
        slider("حد المنطقة السفلي ‰ من الارتفاع", 300, 700, { s.yMax }, { s.yMax = it })
        root.addView(btn("تعيين نقطة فتح الدردشة (اختياري)") {
            AssistService.instance?.pickPoint("اضغط على شريط \"قل شيئاً\" داخل اللعبة") { x, y -> s.chatOpenX = x; s.chatOpenY = y; toast("حُفظت ($x,$y)") }
                ?: toast("فعّل الخدمة أولًا")
        })
        root.addView(btn("تعيين نقطة زر الإرسال (اختياري)") {
            AssistService.instance?.pickPoint("اضغط على زر الإرسال داخل اللعبة") { x, y -> s.sendX = x; s.sendY = y; toast("حُفظت ($x,$y)") }
                ?: toast("فعّل الخدمة أولًا")
        })

        section("الإرسال والتوقيت")
        check("إرسال تلقائي (الافتراضي: تأكيد يدوي بزر ✓ إرسال)", { s.autoSend }, { s.autoSend = it })
        check("انتظر وقتًا متبقيًا محددًا قبل الإرسال", { s.sendAtRemaining }, { s.sendAtRemaining = it })
        slider("الوقت المتبقي المستهدف (مللي ثانية)", 0, 6000, { s.sendAtRemainingMs }, { s.sendAtRemainingMs = it })
        slider("هامش الأمان قبل 00 (مللي ثانية)", 0, 1000, { s.safetyMs }, { s.safetyMs = it })
        slider("تأخير اللقطة (مللي ثانية)", 0, 500, { s.captureDelayMs }, { s.captureDelayMs = it })
        slider("أدنى ثقة لقراءة الاسم %", 0, 95, { s.minOcrConf }, { s.minOcrConf = it })
        check("لا ترسل إلا أثناء جولة نشطة", { s.requireActiveRound }, { s.requireActiveRound = it })
        root.addView(tv("جزء اسم حزمة اللعبة (لتقييد العمل عليها):"))
        root.addView(EditText(this).apply {
            setText(s.gamePkgContains); setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(e: Editable?) { s.gamePkgContains = e.toString() }
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
            })
        })
        root.addView(btn("تصفير سجل المنشن السابق") { AssistService.instance?.resetHistory(); toast("تم") })

        section("اللاعبون المكتشفون (يمكن تصحيح الاسم وتغيير اللون)")
        playersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(playersBox)

        section("سجل المنشنات")
        logTv = tv("—", 13f); root.addView(logTv)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    combine(AppState.status, AppState.running, AppState.serviceConnected) { a, b, c -> Triple(a, b, c) }.collect { (st, run, conn) ->
                        statusTv.text = "الحالة: $st | الخدمة: ${if (conn) "مفعّلة" else "غير مفعّلة"}"
                        startBtn.text = if (run) "إيقاف المساعدة" else "ابدأ المساعدة"
                    }
                }
                launch {
                    combine(AppState.timerText, AppState.timerConfidence) { t, c -> t to c }.collect { (t, c) ->
                        timerTv.text = "الوقت المتبقي: $t | ثقة التقدير: ${(c * 100).toInt()}% | تطبيق: ${AppState.foregroundPkg.value}"
                    }
                }
                launch { AppState.seats.collect { renderPlayers() } }
                launch { AppState.selectedKey.collect { k -> selTv.text = "اللاعب المحدد: ${AppState.seats.value.firstOrNull { it.key == k }?.name ?: "—"}" } }
                launch {
                    AppState.log.collect { l ->
                        val f = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                        logTv.text = if (l.isEmpty()) "—" else l.take(30).joinToString("\n") { "${f.format(Date(it.timeMs))}  ${it.text}  ←  ${it.status}" }
                    }
                }
            }
        }
    }

    private fun toggle() {
        if (!AppState.serviceConnected.value) { toast("فعّل الخدمة من إعدادات الوصول أولًا"); startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)); return }
        AppState.running.value = !AppState.running.value
        if (!AppState.running.value) AppState.status.value = "متوقف"
    }

    private fun renderPlayers() {
        val seats = AppState.seats.value
        val sig = seats.joinToString("|") { it.name }
        if (sig == lastPlayers) return
        lastPlayers = sig
        playersBox.removeAllViews()
        if (seats.isEmpty()) { playersBox.addView(tv("لا يوجد لاعبون مكتشفون بعد")); return }
        seats.forEachIndexed { i, seat ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val color = Button(this).apply {
                text = "●"; setTextColor(s.colorFor(seat.name, i))
                setOnClickListener {
                    val names = arrayOf("سماوي", "أصفر", "وردي", "أخضر", "بنفسجي", "برتقالي", "أبيض", "أحمر")
                    AlertDialog.Builder(this@MainActivity).setTitle("لون ${seat.name}").setItems(names) { _, w ->
                        s.setColor(seat.name, s.palette[w]); setTextColor(s.palette[w])
                    }.show()
                }
            }
            val alias = EditText(this).apply {
                setText(s.aliasFor(seat.name)); setSingleLine(); hint = seat.name
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(e: Editable?) { s.setAlias(seat.name, e.toString()) }
                    override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                    override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                })
            }
            row.addView(color)
            row.addView(alias, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(tv("  ${(seat.conf * 100).toInt()}%"))
            playersBox.addView(row)
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()
}
