package com.example.mentionassist.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.example.mentionassist.core.Settings
import kotlin.coroutines.resume
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine

sealed class Prepare {
    object Ready : Prepare()
    object NoField : Prepare()          // لم يوجد حقل نصي قابل للكتابة عبر Accessibility
    data class Failed(val why: String) : Prepare()
}
sealed class SendResult {
    object Verified : SendResult()
    object Unverified : SendResult()
    data class Failed(val why: String) : SendResult()
}

/** يتعامل مع حقل المحادثة عبر عقد Accessibility فقط (دون أي تجاوز لحماية النظام). */
class ChatSender(private val svc: AccessibilityService, private val s: Settings) {

    private val openHints = listOf("قل شيئ", "say something")
    private val sendHints = listOf("send", "إرسال", "ارسال")

    private fun root() = svc.rootInActiveWindow

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable && n.isVisibleToUser) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    private fun findByText(n: AccessibilityNodeInfo?, needles: List<String>): AccessibilityNodeInfo? {
        if (n == null) return null
        val hay = listOfNotNull(n.text, n.contentDescription, n.hintText).joinToString(" ").lowercase()
        if (hay.isNotBlank() && needles.any { hay.contains(it) }) return n
        for (i in 0 until n.childCount) findByText(n.getChild(i), needles)?.let { return it }
        return null
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        while (cur != null) {
            if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            cur = cur.parent
        }
        return false
    }

    private suspend fun tap(x: Int, y: Int): Boolean = suspendCancellableCoroutine { cont ->
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 50)).build()
        val ok = svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!ok && cont.isActive) cont.resume(false)
    }

    private suspend fun awaitEditable(timeoutMs: Long): AccessibilityNodeInfo? {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            findEditable(root())?.let { return it }
            delay(60)
        }
        return null
    }

    /** يفتح حقل المحادثة إن لزم ويكتب النص فيه، ثم يتحقق أن النص مطابق تمامًا. */
    suspend fun prepare(text: String): Prepare {
        var field = findEditable(root())
        if (field == null) {
            val opener = findByText(root(), openHints)
            val opened = when {
                opener != null -> clickNode(opener) || run {
                    val r = Rect(); opener.getBoundsInScreen(r); tap(r.centerX(), r.centerY())
                }
                s.chatOpenX >= 0 -> tap(s.chatOpenX, s.chatOpenY)
                else -> false
            }
            if (!opened) return Prepare.NoField
            field = awaitEditable(2000) ?: return Prepare.NoField
        }
        val f = field ?: return Prepare.NoField
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) return Prepare.Failed("رفض الحقل كتابة النص")
        delay(80)
        val check = findEditable(root())
        return if (check?.text?.toString() == text) Prepare.Ready else Prepare.Failed("النص في الحقل لا يطابق المطلوب")
    }

    /** يرسل ما في الحقل فقط إذا طابق النص المتوقع، ثم يتحقق من نجاح الإرسال. */
    suspend fun send(expected: String): SendResult {
        val field = findEditable(root()) ?: return SendResult.Failed("حقل المحادثة غير متاح")
        if (field.text?.toString() != expected) return SendResult.Failed("تعذر التأكد من محتوى الرسالة")
        val btn = findByText(root(), sendHints)
        val fired = when {
            btn != null && clickNode(btn) -> true
            s.sendX >= 0 -> tap(s.sendX, s.sendY)
            else -> field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
        }
        if (!fired) return SendResult.Failed("تعذر تنفيذ ضغطة الإرسال")
        delay(450)
        val after = findEditable(root())
        val cleared = after == null || after.text.isNullOrEmpty() || after.text.toString() != expected
        return if (cleared) SendResult.Verified else SendResult.Unverified
    }
}
