package com.example.mentionassist.core

/**
 * يقدّر لحظة وصول المؤقّت الظاهر إلى 00 اعتمادًا على ساعة النظام (elapsedRealtime)،
 * ويصحّح التقدير كلما التُقطت قراءة جديدة. الأرقام الظاهرة بدقة ثانية واحدة،
 * لذا أي لقطتين متتاليتين تحصران لحظة التبدّل بين زمنيهما (عدم يقين = نصف الفاصل).
 */
class TimerTracker(private val staleMs: Long = 2500) {
    private var lastSec: Int? = null
    private var lastAt = 0L
    private var lastSeenAt = 0L
    private val ends = ArrayList<Long>()
    private var uncertainty = 1000L

    @Synchronized
    fun onReading(sec: Int, atMs: Long) {
        val prev = lastSec
        when {
            prev == null || sec > prev -> {            // أول رؤية أو جولة جديدة
                ends.clear()
                ends.add(atMs + sec * 1000L - 500)
                uncertainty = 1000
            }
            sec < prev -> {                            // تبدّل بين اللقطتين
                ends.add((lastAt + atMs) / 2 + sec * 1000L)
                uncertainty = (atMs - lastAt) / 2
            }
        }
        lastSec = sec; lastAt = atMs; lastSeenAt = atMs
    }

    @Synchronized fun displaySeconds(): Int? = lastSec

    @Synchronized
    fun remainingMs(now: Long): Long? {
        if (ends.isEmpty() || lastSec == null) return null
        val sorted = ends.sorted()
        val end = sorted[sorted.size / 2]
        return (end - now).coerceAtLeast(0)
    }

    /** الجولة نشطة: قراءة حديثة، والمؤقّت لم يصل إلى 00. */
    @Synchronized
    fun isActive(now: Long): Boolean {
        val s = lastSec ?: return false
        if (now - lastSeenAt > staleMs || s == 0) return false
        return (remainingMs(now) ?: 0) > 0
    }

    /** ثقة 0..1: تزيد بعدد التبدّلات المرصودة وتقل بعدم اليقين وبقدم القراءة. */
    @Synchronized
    fun confidence(now: Long): Float {
        if (lastSec == null || now - lastSeenAt > staleMs) return 0f
        val n = minOf(ends.size, 4) / 4f
        val u = 1f - (uncertainty.coerceAtMost(1000) / 1500f)
        return (0.25f + 0.75f * n) * u
    }

    @Synchronized fun reset() { lastSec = null; ends.clear(); lastSeenAt = 0 }
}
