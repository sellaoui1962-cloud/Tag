package com.example.mentionassist.service

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.SystemClock
import com.example.mentionassist.core.AppState
import com.example.mentionassist.core.MentionHistory
import com.example.mentionassist.core.Seat
import com.example.mentionassist.core.Settings
import com.example.mentionassist.core.TimerTracker
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** ينسّق: اختيار لاعب -> صياغة -> تجهيز -> انتظار الوقت المناسب -> (تأكيد) -> إرسال -> تحقق. */
class MentionEngine(
    private val svc: AssistService,
    private val s: Settings,
    private val tracker: TimerTracker,
    private val sender: ChatSender
) {
    val history = MentionHistory()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null
    private var confirm: CompletableDeferred<Unit>? = null

    private fun now() = SystemClock.elapsedRealtime()
    private fun log(t: String, st: String) = AppState.addLog(t, st)

    fun onSeatTapped(seat: Seat) {
        if (!AppState.running.value) return
        if (job?.isActive == true) { log(seat.name, "مشغول بعملية سابقة"); return }
        AppState.selectedKey.value = seat.key
        job = scope.launch { run(seat) }
    }

    fun confirmSend() { confirm?.complete(Unit) }

    /** إيقاف فوري لكل الأتمتة. */
    fun killSwitch() {
        job?.cancel(); job = null
        confirm?.cancel(); confirm = null
        AppState.pendingConfirm.value = null
        AppState.selectedKey.value = null
        AppState.running.value = false
        AppState.status.value = "تم الإيقاف الفوري"
        log("—", "إيقاف فوري")
    }

    private fun roundOk(): Boolean = !s.requireActiveRound || tracker.isActive(now())

    private suspend fun run(seat: Seat) {
        val name = s.aliasFor(seat.name)
        if (seat.conf * 100 < s.minOcrConf) { log(name, "رُفض: ثقة قراءة الاسم ${(seat.conf * 100).toInt()}% (عدّل الاسم يدويًا)"); return }
        if (!roundOk()) { log(name, "رُفض: لا توجد جولة نشطة"); return }

        val text = history.peekNext(name)
        AppState.status.value = "تجهيز: $text"
        when (val p = sender.prepare(text)) {
            is Prepare.NoField -> {
                val cm = svc.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("mention", text))
                log(text, "حقل الكتابة غير متاح للأتمتة — نُسخ النص للحافظة (لصق يدوي)")
                return
            }
            is Prepare.Failed -> { log(text, "فشل التجهيز: ${p.why}"); return }
            Prepare.Ready -> log(text, "جُهّزت")
        }

        // انتظار اللحظة المناسبة إن كان وضع "عند وقت متبقٍّ" مفعّلًا
        if (s.sendAtRemaining) {
            val trigger = s.sendAtRemainingMs + s.sendLatencyMs
            while (true) {
                if (!roundOk()) { log(text, "أُلغيت: انتهت الجولة قبل الإرسال"); return }
                val rem = tracker.remainingMs(now()) ?: break
                if (rem <= trigger) break
                delay(minOf(40L, (rem - trigger).coerceAtLeast(5)))
            }
        }

        // تأكيد يدوي إن لم يكن الإرسال التلقائي مفعّلًا
        if (!s.autoSend) {
            val d = CompletableDeferred<Unit>(); confirm = d
            AppState.pendingConfirm.value = text
            while (!d.isCompleted) {
                if (!roundOk()) { AppState.pendingConfirm.value = null; log(text, "أُلغيت: انتهت الجولة قبل التأكيد"); return }
                delay(30)
            }
            AppState.pendingConfirm.value = null
        }

        // حراسة أخيرة قبل الإرسال
        val rem = tracker.remainingMs(now())
        if (!roundOk() || (s.requireActiveRound && (rem == null || rem < s.safetyMs))) {
            log(text, "أُلغيت: الوقت المتبقي لا يكفي"); return
        }
        val t0 = now()
        when (val r = sender.send(text)) {
            SendResult.Verified -> { history.commit(name); log(text, "أُرسلت (تم التحقق)") }
            SendResult.Unverified -> { history.commit(name); log(text, "أُرسلت؟ لم يمكن التحقق — راجع المحادثة") }
            is SendResult.Failed -> log(text, "فشل الإرسال: ${r.why}")
        }
        // تحديث تقدير زمن الإرسال (متوسط متحرك)
        s.sendLatencyMs = ((s.sendLatencyMs * 0.7) + ((now() - t0) * 0.3)).toInt()
        AppState.status.value = "قيد التشغيل"
    }
}
